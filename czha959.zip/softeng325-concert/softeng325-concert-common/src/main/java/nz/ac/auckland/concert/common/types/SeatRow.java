package nz.ac.auckland.concert.common.types;

/**
 * Enumerated type to model seat rows for the concert venue.
 *
 */
public enum SeatRow {
	A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R
}
