package nz.ac.auckland.concert.service.services.mapper;

import nz.ac.auckland.concert.common.dto.ReservationRequestDTO;
import nz.ac.auckland.concert.service.domain.model.ReservationRequest;

public class ReservationRequestMapper {

}
